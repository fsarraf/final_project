version_info = (0, 2, 7)

__version__ = '.'.join(map(str, version_info))
