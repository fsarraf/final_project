Python module to get stock data from the Alpha Vantage Api


